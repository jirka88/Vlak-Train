﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vlak
{
    class management
    {
        public static int skore = 0 ;
        public static int maxskore = 0;      
        public static bool createditor = false;
    }
}
